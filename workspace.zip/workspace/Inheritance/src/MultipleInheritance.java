//class A{
//	void msg() {
//		System.out.println("Welcome Vishal L");
//	}
//}
//class B {
//	void msg() {
//		System.out.println("Welcome Vishal L");
//	}
//}
//class C extends A,B{//
//	
//}
//public class MultipleInheritance {
//	C obj=new C();
//	obj.msg();//Now which msg() method need to invoked so multiple inheritance is not supported in java
//
//}

/*interface A{
	void msg();
}
interface B{
	void msg();
}
class vish implements A,B{

	@Override
	public void msg() {
		System.out.println("hi");
	}
	
		
		
	}

public class MultipleInheritance {
public static void main(String[] args) {
	vish vish=new vish();
	vish.msg();
}

}*/

/*
abstract class A{
	abstract void msg();
		
}
abstract class B {
	abstract void msg();
		
	}

class C extends A,B {
@Override
void msg() {
	System.out.println(":hi");
}
	}

public class MultipleInheritance {
	public static void main(String[] args) {
	C obj=new C();
	obj.msg();
}
}
*/