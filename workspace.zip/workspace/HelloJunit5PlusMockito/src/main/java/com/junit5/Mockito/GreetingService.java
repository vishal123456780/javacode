package com.junit5.Mockito;

public interface GreetingService {
	 String greet1(String name);

}
