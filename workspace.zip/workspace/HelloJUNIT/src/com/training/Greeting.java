package com.training;

public interface Greeting {
	
	String greet(String name);

}
