package package1;

public class Access2 {
	public static void main(String[] args) {
	Access1 a=new  Access1();
	System.out.println(a.name);
	System.out.println(a.rollNo);
	

}
}
