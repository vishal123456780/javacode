package UncheckedException;

public class ArrayBoundException {
	public static void main(String[] args) {
		int arr[]= {0,1,2,3,4,5};
		System.out.println(arr[6]);
		
	}

}
