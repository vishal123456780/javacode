
public class IntegerOneD {
	public static void main(String[] args) {
		int[] values=new int[3];
		System.out.println(values[0]);
		values[0]=1;
		values[1]=2;
		values[2]=3;
		System.out.println(values[0]);
		System.out.println(values[1]);
	    System.out.println(values[2]);
		for(int i=0;i<values.length;i++) {
			System.out.println(values[i]);
			
		}
		int[] v={1,5,10};
		for(int i=0;i<v.length;i++) {
			System.out.println(v[i]);
		}
		
				
	}

}
