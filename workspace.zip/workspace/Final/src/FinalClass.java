//When a class is declared as final it cannot be extended by any subclass class but it can extend other class

final class Bike1 extends she{}


 //class FinalClass extends Bike1{}  //{//The type FinalClass cannot subclass the final
  //class Bike1
  
  //}
 class she{}
