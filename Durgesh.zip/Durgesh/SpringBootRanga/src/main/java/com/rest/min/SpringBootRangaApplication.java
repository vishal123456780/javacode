package com.rest.min;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootRangaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootRangaApplication.class, args);
	}

}
