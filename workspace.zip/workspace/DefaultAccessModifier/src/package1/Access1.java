//Default: The access level of a default modifier is only within the package. 
//It cannot be accessed from outside the package. If you do not specify any access level, it will be the default.
package package1;

public class Access1 {
	 String name="Vishal" ;
	 int rollNo=802587;

}
