package com.infybuzz.cloud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReverseBookApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReverseBookApplication.class, args);
	}

}
