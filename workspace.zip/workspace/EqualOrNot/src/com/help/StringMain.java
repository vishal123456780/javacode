package com.help;
public class StringMain {
	public static void main(String[] args) {
		StringHelper2 sh = new StringHelper2();
		String truncateAInFirst2Positions = sh.truncateAInFirst2Positions("ACB");
		System.out.println(truncateAInFirst2Positions);
		
	}
	
	

}
	


		




