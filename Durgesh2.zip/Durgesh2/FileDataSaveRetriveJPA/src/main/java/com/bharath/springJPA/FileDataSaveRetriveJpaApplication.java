package com.bharath.springJPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileDataSaveRetriveJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(FileDataSaveRetriveJpaApplication.class, args);
	}

}
