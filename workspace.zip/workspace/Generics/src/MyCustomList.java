import java.util.ArrayList;

public class MyCustomList {
	ArrayList<String> list=new ArrayList<>();
	public void addElemet(String element) {
		list.add(element);
		
	}
	public void removeElement(String element) {
		list.remove(element);
	}
	

}
