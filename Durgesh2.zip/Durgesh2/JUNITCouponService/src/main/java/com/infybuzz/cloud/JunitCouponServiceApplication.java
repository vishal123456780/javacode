package com.infybuzz.cloud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JunitCouponServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(JunitCouponServiceApplication.class, args);
	}

}
