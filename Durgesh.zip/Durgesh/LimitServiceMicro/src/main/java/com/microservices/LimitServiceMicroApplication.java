package com.microservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LimitServiceMicroApplication {

	public static void main(String[] args) {
		SpringApplication.run(LimitServiceMicroApplication.class, args);
	}

}
