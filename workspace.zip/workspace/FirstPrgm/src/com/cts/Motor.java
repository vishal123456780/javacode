package com.cts;

public class Motor {
	int speed;
	void Dstart() {
		System.out.println("DucatiStarted");
	}
	void Hstart() {
		System.out.println("HeroStarted");
	}
	

}
