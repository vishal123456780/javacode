package com.junit5.Mockito.Calculator;

public class CalculatorImple implements Calculator {

	public int add(int a, int b) {
		
		return a+b;
	}

}
