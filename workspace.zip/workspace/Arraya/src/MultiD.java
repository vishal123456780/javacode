
public class MultiD {
	public static void main(String[] args) {
		int [][] grid={
			{1,2,3},{4,5,6},{8,9,10}
		};
		/*System.out.println(grid[0][1]);//2
		System.out.println(grid[1][1]);//5
		System.out.println(grid[2][2]);//10*/
		
		for(int row=0;row<grid.length;row++) {
		for(int col=0;col<grid.length;col++) {
			System.out.println(grid[row][col]);
			
		}
			
		
			
		
	}

}
}
