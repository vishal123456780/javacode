package com.junit5;

public interface Greeting {
	
	String greet1(String name);
	

}
