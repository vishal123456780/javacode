import java.util.ArrayList;
import java.util.List;

//We can convert list to array method by calling list.toArray method //doubt see utube
public class ListtoArray {
public static void main(String[] args) {
	List<String> l2 = new ArrayList();
	l2.add("hi");
	l2.add("hello");
	//String[] array =  l2.toArray(new String(l2.size()));
	
	//System.out.println(array);
	
}
}
