package com.in28minutes.microservices;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CurrencyExchangeService2Application {

	public static void main(String[] args) {
		SpringApplication.run(CurrencyExchangeService2Application.class, args);
	}

}
