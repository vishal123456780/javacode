package com.rest.min;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootRangaApplicationTests {

	@Test
	void contextLoads() {
	}

}
