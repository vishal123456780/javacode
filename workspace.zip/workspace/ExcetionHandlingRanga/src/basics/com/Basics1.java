package basics.com;
public class Basics1 {
	public static void main(String[] args) {
		String m = null;
		m.length();
	}

}
//Exception in thread "main" java.lang.NullPointerException
//at basics.com.Basics.main(Basics.java:5)---->this line represent where exception occured
