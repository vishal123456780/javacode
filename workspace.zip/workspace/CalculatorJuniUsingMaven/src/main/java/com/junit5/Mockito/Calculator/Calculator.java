package com.junit5.Mockito.Calculator;

public interface Calculator {
	
	int add(int a, int b);

}
