package com.infybuzz.cloud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AddressServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
