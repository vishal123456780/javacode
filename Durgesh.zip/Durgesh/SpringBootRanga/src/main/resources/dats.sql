insert into User values(101,sysdate(),'aby');
insert into User values(102,sysdate(),'jack');
insert into User values(103,sysdate(),'meow');