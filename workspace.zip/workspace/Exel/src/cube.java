import java.util.Scanner;

public class cube {
	public static void main(String[] args) {
		int x;
		Scanner sc = new Scanner(System.in);
		x = sc.nextInt();
	     System.out.println(Math.pow(x, 3));
	     System.out.println(Math.pow(x, 2));
	     System.out.println(Math.pow(x, 1));
}
}
